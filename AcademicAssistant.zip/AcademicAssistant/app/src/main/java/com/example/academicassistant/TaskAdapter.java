package com.example.academicassistant;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {

    private List<TaskItem> taskItems;

    public TaskAdapter(List<TaskItem> taskItems) {
        this.taskItems = taskItems;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_task, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        TaskItem item = taskItems.get(position);
        holder.tvTaskName.setText(item.getTaskName());
        holder.tvCourseName.setText(item.getCourseName());
        holder.tvDueDate.setText(item.getDueDate());
        holder.tvStatus.setText(item.getStatus());
    }

    @Override
    public int getItemCount() {
        return taskItems.size();
    }

    static class TaskViewHolder extends RecyclerView.ViewHolder {
        TextView tvTaskName, tvCourseName, tvDueDate, tvStatus;

        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTaskName = itemView.findViewById(R.id.tv_task_name);
            tvCourseName = itemView.findViewById(R.id.tv_task_course);
            tvDueDate = itemView.findViewById(R.id.tv_due_date);
            tvStatus = itemView.findViewById(R.id.tv_status);
        }
    }
}