package com.example.academicassistant;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class TasksFragment extends Fragment {

    private EditText etTaskName, etCourseName, etDueDate;
    private RadioGroup rgStatus;
    private Button btnAddTask;
    private RecyclerView recyclerView;
    private TaskAdapter adapter;
    private List<TaskItem> taskItems;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tasks, container, false);

        etTaskName = view.findViewById(R.id.et_task_name);
        etCourseName = view.findViewById(R.id.et_task_course);
        etDueDate = view.findViewById(R.id.et_due_date);
        rgStatus = view.findViewById(R.id.rg_status);
        btnAddTask = view.findViewById(R.id.btn_add_task);
        recyclerView = view.findViewById(R.id.recycler_view_tasks);

        taskItems = new ArrayList<>();
        adapter = new TaskAdapter(taskItems);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        btnAddTask.setOnClickListener(v -> addTask());

        return view;
    }

    private void addTask() {
        String taskName = etTaskName.getText().toString();
        String courseName = etCourseName.getText().toString();
        String dueDate = etDueDate.getText().toString();

        int selectedId = rgStatus.getCheckedRadioButtonId();
        RadioButton radioButton = getView().findViewById(selectedId);
        String status = radioButton.getText().toString();

        if (taskName.isEmpty() || courseName.isEmpty() || dueDate.isEmpty()) {
            Toast.makeText(getContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        TaskItem item = new TaskItem(taskName, courseName, dueDate, status);
        taskItems.add(item);
        adapter.notifyDataSetChanged();

        etTaskName.setText("");
        etCourseName.setText("");
        etDueDate.setText("");
    }
}