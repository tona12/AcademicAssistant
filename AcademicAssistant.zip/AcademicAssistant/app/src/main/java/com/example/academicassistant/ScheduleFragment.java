package com.example.academicassistant;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ScheduleFragment extends Fragment {

    private EditText etCourseName, etDay;
    private TimePicker timePicker;
    private Button btnAddSchedule, btnSetReminder;
    private RecyclerView recyclerView;
    private ScheduleAdapter adapter;
    private List<ScheduleItem> scheduleItems;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_schedule, container, false);

        etCourseName = view.findViewById(R.id.et_course_name);
        etDay = view.findViewById(R.id.et_day);
        timePicker = view.findViewById(R.id.time_picker);
        btnAddSchedule = view.findViewById(R.id.btn_add_schedule);
        btnSetReminder = view.findViewById(R.id.btn_set_reminder);
        recyclerView = view.findViewById(R.id.recycler_view_schedule);

        scheduleItems = new ArrayList<>();
        adapter = new ScheduleAdapter(scheduleItems);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        btnAddSchedule.setOnClickListener(v -> addSchedule());
        btnSetReminder.setOnClickListener(v -> setReminder());

        return view;
    }

    private void addSchedule() {
        String courseName = etCourseName.getText().toString();
        String day = etDay.getText().toString();
        int hour = timePicker.getCurrentHour();
        int minute = timePicker.getCurrentMinute();

        if (courseName.isEmpty() || day.isEmpty()) {
            Toast.makeText(getContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        ScheduleItem item = new ScheduleItem(courseName, day, hour, minute);
        scheduleItems.add(item);
        adapter.notifyDataSetChanged();

        etCourseName.setText("");
        etDay.setText("");
    }

    private void setReminder() {
        if (scheduleItems.isEmpty()) {
            Toast.makeText(getContext(), "No schedule items to set reminder", Toast.LENGTH_SHORT).show();
            return;
        }

        // Here you would implement the reminder logic for all schedule items
        for (ScheduleItem item : scheduleItems) {
            setAlarmForSchedule(item);
        }

        Toast.makeText(getContext(), "Reminders set for all classes", Toast.LENGTH_SHORT).show();
    }

    private void setAlarmForSchedule(ScheduleItem item) {
        AlarmManager alarmManager = (AlarmManager) requireActivity().getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(getContext(), ReminderBroadcast.class);
        intent.putExtra("course", item.getCourseName());
        intent.putExtra("day", item.getDay());

        PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), item.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT);

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, item.getHour());
        calendar.set(Calendar.MINUTE, item.getMinute());
        calendar.set(Calendar.SECOND, 0);

        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),
                AlarmManager.INTERVAL_DAY * 7, pendingIntent);
    }
}