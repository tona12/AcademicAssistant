package com.example.academicassistant;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ShareFragment extends Fragment {

    private Button btnShareNotes, btnShareTasks, btnShareSchedule;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_share, container, false);

        btnShareNotes = view.findViewById(R.id.btn_share_notes);
        btnShareTasks = view.findViewById(R.id.btn_share_tasks);
        btnShareSchedule = view.findViewById(R.id.btn_share_schedule);

        btnShareNotes.setOnClickListener(v -> shareContent("notes"));
        btnShareTasks.setOnClickListener(v -> shareContent("tasks"));
        btnShareSchedule.setOnClickListener(v -> shareContent("schedule"));

        return view;
    }

    private void shareContent(String contentType) {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");

        String shareMessage = "";
        switch (contentType) {
            case "notes":
                shareMessage = "أريد مشاركة ملاحظاتي معك من تطبيق المساعد الأكاديمي";
                break;
            case "tasks":
                shareMessage = "أريد مشاركة المهام والواجبات معك من تطبيق المساعد الأكاديمي";
                break;
            case "schedule":
                shareMessage = "أريد مشاركة جدول الدروس معك من تطبيق المساعد الأكاديمي";
                break;
        }

        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
        startActivity(Intent.createChooser(shareIntent, "مشاركة عبر"));
    }
}