package com.example.academicassistant;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> {

    private List<NoteItem> noteItems;

    public NoteAdapter(List<NoteItem> noteItems) {
        this.noteItems = noteItems;
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_note, parent, false);
        return new NoteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {
        NoteItem item = noteItems.get(position);
        holder.tvNoteTitle.setText(item.getTitle());
        holder.tvNoteContent.setText(item.getContent());
        holder.tvNoteCourse.setText(item.getCourse());
    }

    @Override
    public int getItemCount() {
        return noteItems.size();
    }

    static class NoteViewHolder extends RecyclerView.ViewHolder {
        TextView tvNoteTitle, tvNoteContent, tvNoteCourse;

        public NoteViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNoteTitle = itemView.findViewById(R.id.tv_note_title);
            tvNoteContent = itemView.findViewById(R.id.tv_note_content);
            tvNoteCourse = itemView.findViewById(R.id.tv_note_course);
        }
    }
}