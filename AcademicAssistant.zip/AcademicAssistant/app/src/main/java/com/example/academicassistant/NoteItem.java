package com.example.academicassistant;

public class NoteItem {
    private String title;
    private String content;
    private String course;

    public NoteItem(String title, String content, String course) {
        this.title = title;
        this.content = content;
        this.course = course;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public String getCourse() {
        return course;
    }
}