package com.example.academicassistant;

public class ScheduleItem {
    private String courseName;
    private String day;
    private int hour;
    private int minute;

    public ScheduleItem(String courseName, String day, int hour, int minute) {
        this.courseName = courseName;
        this.day = day;
        this.hour = hour;
        this.minute = minute;
    }

    public String getCourseName() {
        return courseName;
    }

    public String getDay() {
        return day;
    }

    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }
}