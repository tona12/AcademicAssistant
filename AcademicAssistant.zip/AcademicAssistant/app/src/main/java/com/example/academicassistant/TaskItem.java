package com.example.academicassistant;

public class TaskItem {
    private String taskName;
    private String courseName;
    private String dueDate;
    private String status;

    public TaskItem(String taskName, String courseName, String dueDate, String status) {
        this.taskName = taskName;
        this.courseName = courseName;
        this.dueDate = dueDate;
        this.status = status;
    }

    public String getTaskName() {
        return taskName;
    }

    public String getCourseName() {
        return courseName;
    }

    public String getDueDate() {
        return dueDate;
    }

    public String getStatus() {
        return status;
    }
}